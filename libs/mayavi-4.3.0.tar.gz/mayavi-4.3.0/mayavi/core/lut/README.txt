This directory contains lookup tables imported from pylab automaticaly by
"cm2lut" script. Do not modify manually

These colormaps are borrowed from matplotlib. See matplotlib license
for license agreement (http://matplotlib.sourceforge.net/license.html)

34 of the colormaps are based on color specifications and designs
developed by Cynthia Brewer (http://colorbrewer.org). The ColorBrewer
palettes have been included under the terms of an Apache-stype license
(for details, see the file LICENSE_COLORBREWER in the base directory of
mayavi source).

7 palettes are from the Yorick scientific visalisation package, an
evolution of the GIST package, both by David H. Munro. They are
released under a BSD-like license (see LICENSE_YORICK in the base
directory of mayavi source).

