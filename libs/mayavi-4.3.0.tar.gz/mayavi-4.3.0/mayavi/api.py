from mayavi.version import version, version as __version__
from mayavi.core.engine import Engine
from mayavi.core.off_screen_engine import OffScreenEngine
from mayavi.tests.runtests import m2_tests as test
