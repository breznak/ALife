

.. _example_subclassing_mayavi_application:

Subclassing mayavi application example
--------------------------------------------


This script demonstrates how one can script the Mayavi application by
subclassing the application, create a new scene and create a few
simple modules.

This should be run as::

   $ python test.py



**Python source code:** :download:`subclassing_mayavi_application.py`

.. literalinclude:: subclassing_mayavi_application.py
    :lines: 12-


    