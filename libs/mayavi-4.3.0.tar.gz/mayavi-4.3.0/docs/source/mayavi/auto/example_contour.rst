

.. _example_contour:

Contour example
--------------------------------------------


This script demonstrates how one can script Mayavi and use its
contour related modules.



**Python source code:** :download:`contour.py`

.. literalinclude:: contour.py
    :lines: 7-


    