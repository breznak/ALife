

.. _example_streamline:

Streamline example
--------------------------------------------

This script demonstrates how one can script Mayavi's core API to display
streamlines and an iso surface.


**Python source code:** :download:`streamline.py`

.. literalinclude:: streamline.py
    :lines: 5-


    