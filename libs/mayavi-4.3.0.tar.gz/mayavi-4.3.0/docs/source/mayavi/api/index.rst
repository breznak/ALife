
Mayavi API reference
=======================

.. toctree::
    :maxdepth: 2

    pipeline_objects.rst
    core_view_objects.rst

