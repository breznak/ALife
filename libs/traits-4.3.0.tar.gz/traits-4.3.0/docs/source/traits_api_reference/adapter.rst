:mod:`adapter` Module
=====================

.. automodule:: traits.adapter
    :no-members:

Class
-----

.. autoclass:: Adapter

    .. automethod:: __init__


.. autoclass:: DefaultAdapterFactory

Function
--------

.. autofunction:: adapts
