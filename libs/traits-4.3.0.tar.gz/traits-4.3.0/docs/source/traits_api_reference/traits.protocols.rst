protocols Package
=================

:mod:`protocols` Package
------------------------

.. automodule:: traits.protocols
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`adapters` Module
----------------------

.. automodule:: traits.protocols.adapters
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`advice` Module
--------------------

.. automodule:: traits.protocols.advice
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`classic` Module
---------------------

.. automodule:: traits.protocols.classic
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`generate` Module
----------------------

.. automodule:: traits.protocols.generate
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`interfaces` Module
------------------------

.. automodule:: traits.protocols.interfaces
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`protocols` Module
-----------------------

.. automodule:: traits.protocols.protocols
    :members:
    :undoc-members:
    :show-inheritance:

