:mod:`trait_numeric` Module
===========================

.. automodule:: traits.trait_numeric
    :no-members:

Classes
-------

.. autoclass:: AbstractArray

.. autoclass:: Array

.. autoclass:: CArray

Function
--------

.. autofunction:: dtype2trait

