:mod:`category` Module
======================

.. automodule:: traits.category
    :no-members:

Classes
-------

.. autoclass:: MetaCategory

.. autoclass:: MetaCategoryObject

.. autoclass:: Category