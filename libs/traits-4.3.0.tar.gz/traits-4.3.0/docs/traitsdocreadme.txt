Traits documentation files in this directory:

Traits3_UM.pdf
    PDF version of User's Manual
Traits3_UM.doc
    MS Word source for User's Manual
Traits3_UM_add.css
    CSS to add when using Pydoh on the User's Manual
