
from deprecated import deprecated

