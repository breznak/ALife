Traits documentation files in this directory:

Traits UI User Guide.doc
    Lyn Pierce's tutorial user guide for Traits UI
Traits UI User Guide.pdf
    PDF version of Traits UI UG.
traits_ui.ppt
    Slides from Dave Morrill's class on Traits UI
traits_ui_slides.pdf
    PDF of Traits UI slides

