.. TraitsUI documentation master file, created by sphinx-quickstart on Mon Aug 18 11:27:34 2008.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

TraitsUI 4 User Manual
======================

.. toctree::
   :maxdepth: 3

   front.rst
   intro.rst
   view.rst
   custom_view.rst
   advanced_view.rst
   handler.rst
   themes.rst
   factory_intro.rst
   factories_basic.rst
   factories_advanced_extra.rst
   tips.rst
   glossary.rst
   predefined_traits.rst
   
