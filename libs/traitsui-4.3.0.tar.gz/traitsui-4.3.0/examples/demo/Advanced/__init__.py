"""
These demonstrations show off some of the more advanced features of and
TraitsUI.
"""
