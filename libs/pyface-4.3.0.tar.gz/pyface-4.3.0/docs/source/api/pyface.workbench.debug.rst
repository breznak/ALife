debug Package
=============

:mod:`api` Module
-----------------

.. automodule:: pyface.workbench.debug.api
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`debug_view` Module
------------------------

.. automodule:: pyface.workbench.debug.debug_view
    :members:
    :undoc-members:
    :show-inheritance:

