timer Package
=============

:mod:`timer` Package
--------------------

.. automodule:: pyface.ui.wx.timer
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`do_later` Module
----------------------

.. automodule:: pyface.ui.wx.timer.do_later
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`timer` Module
-------------------

.. automodule:: pyface.ui.wx.timer.timer
    :members:
    :undoc-members:
    :show-inheritance:

