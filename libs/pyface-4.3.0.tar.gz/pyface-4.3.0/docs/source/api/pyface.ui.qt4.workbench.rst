workbench Package
=================

:mod:`workbench` Package
------------------------

.. automodule:: pyface.ui.qt4.workbench
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`editor` Module
--------------------

.. automodule:: pyface.ui.qt4.workbench.editor
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`split_tab_widget` Module
------------------------------

.. automodule:: pyface.ui.qt4.workbench.split_tab_widget
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`view` Module
------------------

.. automodule:: pyface.ui.qt4.workbench.view
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`workbench_window_layout` Module
-------------------------------------

.. automodule:: pyface.ui.qt4.workbench.workbench_window_layout
    :members:
    :undoc-members:
    :show-inheritance:

