sizers Package
==============

:mod:`flow` Module
------------------

.. automodule:: pyface.sizers.flow
    :members:
    :undoc-members:
    :show-inheritance:

