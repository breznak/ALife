wizard Package
==============

:mod:`wizard` Package
---------------------

.. automodule:: pyface.ui.wx.wizard
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`wizard` Module
--------------------

.. automodule:: pyface.ui.wx.wizard.wizard
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`wizard_page` Module
-------------------------

.. automodule:: pyface.ui.wx.wizard.wizard_page
    :members:
    :undoc-members:
    :show-inheritance:

