action Package
==============

:mod:`api` Module
-----------------

.. automodule:: pyface.tasks.action.api
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`dock_pane_toggle_group` Module
------------------------------------

.. automodule:: pyface.tasks.action.dock_pane_toggle_group
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`listening_action` Module
------------------------------

.. automodule:: pyface.tasks.action.listening_action
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`schema` Module
--------------------

.. automodule:: pyface.tasks.action.schema
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`schema_addition` Module
-----------------------------

.. automodule:: pyface.tasks.action.schema_addition
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`task_action` Module
-------------------------

.. automodule:: pyface.tasks.action.task_action
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`task_action_controller` Module
------------------------------------

.. automodule:: pyface.tasks.action.task_action_controller
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`task_action_manager_builder` Module
-----------------------------------------

.. automodule:: pyface.tasks.action.task_action_manager_builder
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`task_toggle_group` Module
-------------------------------

.. automodule:: pyface.tasks.action.task_toggle_group
    :members:
    :undoc-members:
    :show-inheritance:

