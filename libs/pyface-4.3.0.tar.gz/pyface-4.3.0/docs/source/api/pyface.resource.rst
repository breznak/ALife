resource Package
================

:mod:`resource` Package
-----------------------

.. automodule:: pyface.resource
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`api` Module
-----------------

.. automodule:: pyface.resource.api
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`resource_factory` Module
------------------------------

.. automodule:: pyface.resource.resource_factory
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`resource_manager` Module
------------------------------

.. automodule:: pyface.resource.resource_manager
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`resource_path` Module
---------------------------

.. automodule:: pyface.resource.resource_path
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`resource_reference` Module
--------------------------------

.. automodule:: pyface.resource.resource_reference
    :members:
    :undoc-members:
    :show-inheritance:

