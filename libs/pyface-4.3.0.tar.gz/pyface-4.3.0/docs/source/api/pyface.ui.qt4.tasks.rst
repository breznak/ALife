tasks Package
=============

:mod:`advanced_editor_area_pane` Module
---------------------------------------

.. automodule:: pyface.ui.qt4.tasks.advanced_editor_area_pane
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`dock_pane` Module
-----------------------

.. automodule:: pyface.ui.qt4.tasks.dock_pane
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`editor` Module
--------------------

.. automodule:: pyface.ui.qt4.tasks.editor
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`editor_area_pane` Module
------------------------------

.. automodule:: pyface.ui.qt4.tasks.editor_area_pane
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`main_window_layout` Module
--------------------------------

.. automodule:: pyface.ui.qt4.tasks.main_window_layout
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`task_pane` Module
-----------------------

.. automodule:: pyface.ui.qt4.tasks.task_pane
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`task_window_backend` Module
---------------------------------

.. automodule:: pyface.ui.qt4.tasks.task_window_backend
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`util` Module
------------------

.. automodule:: pyface.ui.qt4.tasks.util
    :members:
    :undoc-members:
    :show-inheritance:

