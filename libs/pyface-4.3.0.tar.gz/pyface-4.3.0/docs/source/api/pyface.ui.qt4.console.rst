console Package
===============

:mod:`api` Module
-----------------

.. automodule:: pyface.ui.qt4.console.api
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`bracket_matcher` Module
-----------------------------

.. automodule:: pyface.ui.qt4.console.bracket_matcher
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`call_tip_widget` Module
-----------------------------

.. automodule:: pyface.ui.qt4.console.call_tip_widget
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`completion_lexer` Module
------------------------------

.. automodule:: pyface.ui.qt4.console.completion_lexer
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`console_widget` Module
----------------------------

.. automodule:: pyface.ui.qt4.console.console_widget
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`history_console_widget` Module
------------------------------------

.. automodule:: pyface.ui.qt4.console.history_console_widget
    :members:
    :undoc-members:
    :show-inheritance:

