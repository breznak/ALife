workbench Package
=================

:mod:`workbench` Package
------------------------

.. automodule:: pyface.ui.wx.workbench
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`editor` Module
--------------------

.. automodule:: pyface.ui.wx.workbench.editor
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`editor_set_structure_handler` Module
------------------------------------------

.. automodule:: pyface.ui.wx.workbench.editor_set_structure_handler
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`view` Module
------------------

.. automodule:: pyface.ui.wx.workbench.view
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`view_set_structure_handler` Module
----------------------------------------

.. automodule:: pyface.ui.wx.workbench.view_set_structure_handler
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`workbench_dock_window` Module
-----------------------------------

.. automodule:: pyface.ui.wx.workbench.workbench_dock_window
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`workbench_window_layout` Module
-------------------------------------

.. automodule:: pyface.ui.wx.workbench.workbench_window_layout
    :members:
    :undoc-members:
    :show-inheritance:

