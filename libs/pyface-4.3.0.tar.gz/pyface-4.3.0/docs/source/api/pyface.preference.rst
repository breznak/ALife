preference Package
==================

:mod:`preference` Package
-------------------------

.. automodule:: pyface.preference
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`api` Module
-----------------

.. automodule:: pyface.preference.api
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`preference_dialog` Module
-------------------------------

.. automodule:: pyface.preference.preference_dialog
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`preference_node` Module
-----------------------------

.. automodule:: pyface.preference.preference_node
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`preference_page` Module
-----------------------------

.. automodule:: pyface.preference.preference_page
    :members:
    :undoc-members:
    :show-inheritance:

