contrib Package
===============

:mod:`python_shell` Module
--------------------------

.. automodule:: pyface.tasks.contrib.python_shell
    :members:
    :undoc-members:
    :show-inheritance:

