action Package
==============

:mod:`action` Package
---------------------

.. automodule:: pyface.ui.qt4.action
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`action_item` Module
-------------------------

.. automodule:: pyface.ui.qt4.action.action_item
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`menu_bar_manager` Module
------------------------------

.. automodule:: pyface.ui.qt4.action.menu_bar_manager
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`menu_manager` Module
--------------------------

.. automodule:: pyface.ui.qt4.action.menu_manager
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`status_bar_manager` Module
--------------------------------

.. automodule:: pyface.ui.qt4.action.status_bar_manager
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`tool_bar_manager` Module
------------------------------

.. automodule:: pyface.ui.qt4.action.tool_bar_manager
    :members:
    :undoc-members:
    :show-inheritance:

