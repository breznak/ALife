timer Package
=============

:mod:`api` Module
-----------------

.. automodule:: pyface.timer.api
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`do_later` Module
----------------------

.. automodule:: pyface.timer.do_later
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`timer` Module
-------------------

.. automodule:: pyface.timer.timer
    :members:
    :undoc-members:
    :show-inheritance:

