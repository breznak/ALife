code_editor Package
===================

:mod:`code_editor` Package
--------------------------

.. automodule:: pyface.ui.qt4.code_editor
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`code_widget` Module
-------------------------

.. automodule:: pyface.ui.qt4.code_editor.code_widget
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`find_widget` Module
-------------------------

.. automodule:: pyface.ui.qt4.code_editor.find_widget
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`gutters` Module
---------------------

.. automodule:: pyface.ui.qt4.code_editor.gutters
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`pygments_highlighter` Module
----------------------------------

.. automodule:: pyface.ui.qt4.code_editor.pygments_highlighter
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`replace_widget` Module
----------------------------

.. automodule:: pyface.ui.qt4.code_editor.replace_widget
    :members:
    :undoc-members:
    :show-inheritance:

