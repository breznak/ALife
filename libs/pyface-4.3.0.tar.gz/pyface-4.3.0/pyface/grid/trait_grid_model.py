import logging
logging.warn('DEPRECATED: pyface.grid, '
             'use pyface.ui.wx.grid instead.')

from pyface.ui.wx.grid.trait_grid_model import *
