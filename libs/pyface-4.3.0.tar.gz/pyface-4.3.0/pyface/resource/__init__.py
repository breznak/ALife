# Copyright (c) 2005-2011, Enthought, Inc.
# All rights reserved.
""" Support for managing resources such as images and sounds.
    Part of the TraitsGUI project of the Enthought Tool Suite.
"""
