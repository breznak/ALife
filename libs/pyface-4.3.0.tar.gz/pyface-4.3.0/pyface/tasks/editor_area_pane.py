# Import the toolkit specific version.
from pyface.toolkit import toolkit_object
EditorAreaPane = toolkit_object('tasks.editor_area_pane:EditorAreaPane')
