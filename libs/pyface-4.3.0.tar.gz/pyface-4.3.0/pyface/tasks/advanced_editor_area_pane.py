# Import the toolkit specific version.
from pyface.toolkit import toolkit_object
AdvancedEditorAreaPane = toolkit_object('tasks.advanced_editor_area_pane:'
                                        'AdvancedEditorAreaPane')
