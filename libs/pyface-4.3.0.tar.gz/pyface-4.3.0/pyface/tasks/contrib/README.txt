This subpackage is for Tasks components that are generic and re-usable, but not
required for the proper functioning of Tasks.

In other words, if this subpackage were to be completely removed, there should
be no breakage in Tasks.
