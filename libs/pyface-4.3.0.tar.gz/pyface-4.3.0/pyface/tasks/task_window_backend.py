# Import the toolkit specific version.
from pyface.toolkit import toolkit_object
TaskWindowBackend = toolkit_object(
    'tasks.task_window_backend:TaskWindowBackend')
