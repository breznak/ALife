# Copyright (c) 2007-2013 by Enthought, Inc.
# All rights reserved.

__version__ = '4.2.0'

__requires__ = [
    'traitsui',
    'configobj',
]
