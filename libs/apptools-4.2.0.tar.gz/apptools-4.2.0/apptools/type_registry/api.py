from .type_registry import LazyRegistry, TypeRegistry
