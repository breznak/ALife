#------------------------------------------------------------------------------
# Copyright (c) 2005, Enthought, Inc.
# All rights reserved.
#------------------------------------------------------------------------------
""" Support for online help in Traits and Envisage.
    Part of the AppTools project of the Enthought Tool Suite.
"""
